<?php
	$host = "localhost";
	$dbuser = "root";
	$dbpass = "";
	$dbname = "spc";
	$db = mysqli_connect($host, $dbuser, $dbpass, $dbname);
	
?>